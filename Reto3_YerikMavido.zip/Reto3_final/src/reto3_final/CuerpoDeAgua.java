package reto3_final;

public class CuerpoDeAgua extends ObjetoGeografico {
    private String tipoCuerpoAgua;
    private String tipoAgua;
    private double irca;

    public CuerpoDeAgua(int id, String nombre, String municipio, String tipoCuerpoAgua, String tipoAgua, double irca) {
        super(id, nombre, municipio);
        this.tipoCuerpoAgua = tipoCuerpoAgua;
        this.tipoAgua = tipoAgua;
        this.irca = irca;
    }

    public String nivel() {
        if (irca >= 0 && irca <= 5) {
            return "SIN RIESGO";
        } else if (irca > 5 && irca <= 14) {
            return "BAJO";
        } else if (irca > 14 && irca <= 35) {
            return "MEDIO";
        } else if (irca > 35 && irca <= 80) {
            return "ALTO";
        } else if (irca > 80 && irca <= 100) {
            return "INVIABLE SANITARIAMENTE";
        }
        return "DESCONOCIDO";
    }

    public String getTipoCuerpoAgua() { return tipoCuerpoAgua; }
    public String getTipoAgua() { return tipoAgua; }
    public double getIrca() { return irca; }
}
