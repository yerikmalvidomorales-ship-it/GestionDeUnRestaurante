package reto3_final;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ConexionBD {
    private static final String URL = "jdbc:sqlite:base_datos_agua.db";

    public static Connection conectar() {
    Connection conn = null;
    try {
        // Carga explícita del driver para que Java no lo pierda de vista
        Class.forName("org.sqlite.JDBC");
        
        // Abre la conexión a la base de datos
        conn = DriverManager.getConnection("jdbc:sqlite:base_datos_agua.db");
    } catch (Exception e) {
        System.out.println("Error al conectar: " + e.getMessage());
    }
    return conn;
}

    public static void crearTabla() {
        String sql = "CREATE TABLE IF NOT EXISTS cuerpos_agua (" +
                     "id INTEGER PRIMARY KEY, " +
                     "nombre TEXT, " +
                     "municipio TEXT, " +
                     "tipo_cuerpo TEXT, " +
                     "tipo_agua TEXT, " +
                     "irca REAL);";
        try (Connection conn = conectar(); Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            System.out.println("Error tabla: " + e.getMessage());
        }
    }

    public static boolean insertar(CuerpoDeAgua ca) {
        String sql = "INSERT INTO cuerpos_agua VALUES(?,?,?,?,?,?)";
        try (Connection conn = conectar(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, ca.getId());
            pstmt.setString(2, ca.getNombre());
            pstmt.setString(3, ca.getMunicipio());
            pstmt.setString(4, ca.getTipoCuerpoAgua());
            pstmt.setString(5, ca.getTipoAgua());
            pstmt.setDouble(6, ca.getIrca());
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            return false;
        }
    }

    public static List<CuerpoDeAgua> obtenerTodos() {
        List<CuerpoDeAgua> lista = new ArrayList<>();
        String sql = "SELECT * FROM cuerpos_agua";
        try (Connection conn = conectar(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                lista.add(new CuerpoDeAgua(
                    rs.getInt("id"), rs.getString("nombre"), rs.getString("municipio"),
                    rs.getString("tipo_cuerpo"), rs.getString("tipo_agua"), rs.getDouble("irca")
                ));
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return lista;
    }

    public static CuerpoDeAgua buscarPorId(int id) {
        String sql = "SELECT * FROM cuerpos_agua WHERE id = ?";
        try (Connection conn = conectar(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return new CuerpoDeAgua(
                    rs.getInt("id"), rs.getString("nombre"), rs.getString("municipio"),
                    rs.getString("tipo_cuerpo"), rs.getString("tipo_agua"), rs.getDouble("irca")
                );
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return null;
    }

    public static boolean actualizar(CuerpoDeAgua ca) {
        String sql = "UPDATE cuerpos_agua SET nombre=?, municipio=?, tipo_cuerpo=?, tipo_agua=?, irca=? WHERE id=?";
        try (Connection conn = conectar(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, ca.getNombre());
            pstmt.setString(2, ca.getMunicipio());
            pstmt.setString(3, ca.getTipoCuerpoAgua());
            pstmt.setString(4, ca.getTipoAgua());
            pstmt.setDouble(5, ca.getIrca());
            pstmt.setInt(6, ca.getId());
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            return false;
        }
    }

    public static boolean eliminar(int id) {
        String sql = "DELETE FROM cuerpos_agua WHERE id = ?";
        try (Connection conn = conectar(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            return false;
        }
    }
}
