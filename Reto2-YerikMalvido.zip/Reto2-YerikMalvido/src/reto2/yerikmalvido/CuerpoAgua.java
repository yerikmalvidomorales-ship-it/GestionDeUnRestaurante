/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package reto2.yerikmalvido;


public class CuerpoAgua extends ObjetoGeografico {
 String tipoCuerpo;
    String tipoAgua;
    double irca;

    public CuerpoAgua(String nombre, int identificador, String municipio,
                        String tipoCuerpo, String tipoAgua, double irca) {

        super(nombre, identificador, municipio);

        this.tipoCuerpo = tipoCuerpo;
        this.tipoAgua = tipoAgua;
        this.irca = irca;
    }

    public String nivel() {

        if (irca <= 5) {
            return "SIN RIESGO";
        }

        if (irca <= 14) {
            return "BAJO";
        }

        if (irca <= 35) {
            return "MEDIO";
        }

        if (irca <= 80) {
            return "ALTO";
        }

        return "INVIABLE SANITARIAMENTE";
    }
}
