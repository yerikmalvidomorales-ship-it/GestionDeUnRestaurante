/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package reto2.yerikmalvido;

public class ObjetoGeografico {
    

    String nombre;
    int identificador;
    String municipio;

    public ObjetoGeografico(String nombre, int identificador, String municipio) {

        this.nombre = nombre;
        this.identificador = identificador;
        this.municipio = municipio;

    }

}
